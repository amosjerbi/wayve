package com.romnix.app.ui.screens

import android.content.Intent
import android.net.Uri
import com.romnix.app.MonitorStarter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.romnix.app.MainViewModel
import com.romnix.app.R
import com.romnix.app.data.NowPlayingData
import com.romnix.app.data.NowPlayingParser
import com.romnix.app.data.NowPlayingTrack
import com.romnix.app.ui.theme.ButtonStyles
import com.romnix.app.service.NowPlayingCaptureService
import com.romnix.app.service.NowPlayingAccessibilityService
import com.romnix.app.service.NowPlayingMonitorService
import android.provider.Settings
import androidx.compose.runtime.DisposableEffect
import androidx.documentfile.provider.DocumentFile
import android.content.ComponentName

/**
 * Helper function for surface variant darker (used in empty states)
 */
@Composable
private fun surfaceVariantDarker(): Color {
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val isLight = surfaceVariant.luminance() > 0.5f
    return if (isLight) {
        Color(
            red = (surfaceVariant.red * 0.9f).coerceIn(0f, 1f),
            green = (surfaceVariant.green * 0.9f).coerceIn(0f, 1f),
            blue = (surfaceVariant.blue * 0.9f).coerceIn(0f, 1f)
        )
    } else {
        Color(
            red = (surfaceVariant.red * 1.3f).coerceIn(0f, 1f),
            green = (surfaceVariant.green * 1.3f).coerceIn(0f, 1f),
            blue = (surfaceVariant.blue * 1.3f).coerceIn(0f, 1f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val captureService = remember { NowPlayingCaptureService(context) }
    val sharedPrefs = remember { context.getSharedPreferences("wayve_prefs", android.content.Context.MODE_PRIVATE) }
    
    var selectedTab by remember { mutableStateOf(0) } // 0=Library, 1=Analytics
    var nowPlayingData by remember { mutableStateOf<NowPlayingData?>(null) }
    var filteredTracks by remember { mutableStateOf<List<NowPlayingTrack>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var sortBy by remember { mutableStateOf("time") } // time, title, artist
    var showCaptureDialog by remember { mutableStateOf(false) }
    var showAccessibilityDialog by remember { mutableStateOf(false) }
    var selectedSaveLocation by remember { mutableStateOf<Uri?>(null) }
    var saveLocationName by remember { mutableStateOf("") }
    var isCapturing by remember { mutableStateOf(false) }
    var captureProgress by remember { mutableStateOf("") }
    var capturedTrackCount by remember { mutableStateOf(0) }
    var scrollAttemptCount by remember { mutableStateOf(0) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showOpenWithDialog by remember { mutableStateOf(false) }
    var showShazamSettingsDialog by remember { mutableStateOf(false) }
    var selectedMusicApp by remember { mutableStateOf(sharedPrefs.getString("selected_music_app", "YouTube") ?: "YouTube") }
    var autoDetectionEnabled by remember { mutableStateOf(sharedPrefs.getBoolean("auto_detection_enabled", false)) }
    var continuousMonitorEnabled by remember { mutableStateOf(sharedPrefs.getBoolean("continuous_monitor_enabled", false)) }
    var showNotificationListenerDialog by remember { mutableStateOf(false) }
    var showMicrophonePermissionDialog by remember { mutableStateOf(false) }
    var forceRefresh by remember { mutableStateOf(0) } // Used to force UI refresh
    
    // Load saved data on first composition
    LaunchedEffect(Unit) {
        val savedData = sharedPrefs.getString("nowplaying_data", null)
        if (savedData != null) {
            try {
                val data = kotlinx.serialization.json.Json {
                    ignoreUnknownKeys = true
                }.decodeFromString<NowPlayingData>(savedData)
                nowPlayingData = data
                filteredTracks = data.tracks
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    // Save data whenever it changes
    LaunchedEffect(nowPlayingData) {
        nowPlayingData?.let { data ->
            try {
                val jsonString = kotlinx.serialization.json.Json {
                    prettyPrint = false
                }.encodeToString(NowPlayingData.serializer(), data)
                sharedPrefs.edit().putString("nowplaying_data", jsonString).apply()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    // Helper function to check if notification listener is enabled
    fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        )
        val componentName = ComponentName(context, NowPlayingMonitorService::class.java)
        return enabledListeners?.contains(componentName.flattenToString()) == true
    }
    
    // Save selected music app whenever it changes
    LaunchedEffect(selectedMusicApp) {
        sharedPrefs.edit().putString("selected_music_app", selectedMusicApp).apply()
    }
    
    // Check if microphone permission is granted
    fun hasMicrophonePermission(): Boolean {
        return context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    // Microphone permission launcher
    val microphonePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Permission granted, start continuous monitor
            continuousMonitorEnabled = true
        } else {
            android.widget.Toast.makeText(
                context,
                "Microphone permission required for continuous monitoring",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }
    
    // Save auto-detection setting and manage foreground service
    LaunchedEffect(autoDetectionEnabled) {
        sharedPrefs.edit().putBoolean("auto_detection_enabled", autoDetectionEnabled).apply()
        NowPlayingMonitorService.isAutoDetectionEnabled = autoDetectionEnabled
        
        if (autoDetectionEnabled) {
            // Start foreground service for Now Playing detection
            val serviceIntent = Intent(context, com.romnix.app.service.NowPlayingMonitorService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            android.util.Log.d("NowPlayingScreen", "Now Playing detection enabled")
        } else {
            android.util.Log.d("NowPlayingScreen", "Now Playing detection disabled")
        }
    }
    
    // Manage continuous monitor service
    // NOTE: Service is now started automatically by MainActivity
    // This LaunchedEffect only saves the preference state
    LaunchedEffect(continuousMonitorEnabled) {
        sharedPrefs.edit().putBoolean("continuous_monitor_enabled", continuousMonitorEnabled).apply()
        android.util.Log.d("NowPlayingScreen", "Continuous monitor preference: $continuousMonitorEnabled")
    }
    
    // Auto-refresh every 5 seconds to catch new detections
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(5000) // Check every 5 seconds
            
            // Check if data changed
            val savedData = sharedPrefs.getString("nowplaying_data", null)
            if (savedData != null) {
                try {
                    val data = kotlinx.serialization.json.Json {
                        ignoreUnknownKeys = true
                    }.decodeFromString<NowPlayingData>(savedData)
                    
                    // Only update if track count changed
                    if (data.tracks.size != nowPlayingData?.tracks?.size) {
                        android.util.Log.d("NowPlayingScreen", "🔄 Auto-refresh: New tracks detected!")
                        forceRefresh++
                    }
                } catch (e: Exception) {
                    // Ignore parse errors
                }
            }
        }
    }
    
    // Reload data when forceRefresh changes
    LaunchedEffect(forceRefresh) {
        if (forceRefresh > 0) {
            val savedData = sharedPrefs.getString("nowplaying_data", null)
            if (savedData != null) {
                try {
                    val data = kotlinx.serialization.json.Json {
                        ignoreUnknownKeys = true
                    }.decodeFromString<NowPlayingData>(savedData)
                    nowPlayingData = data
                    filteredTracks = data.tracks
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
    
    // Setup auto-detection callback
    DisposableEffect(Unit) {
        // Set callback for when new tracks are detected
        NowPlayingMonitorService.onNewTrackDetected = { newTrack ->
            android.util.Log.d("NowPlayingScreen", "New track detected callback: ${newTrack.title}")
            
            // Force UI refresh
            forceRefresh++
            
            // Show toast notification
            android.widget.Toast.makeText(
                context,
                "🎵 Added: ${newTrack.title}",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
        
        onDispose {
            NowPlayingMonitorService.onNewTrackDetected = null
        }
    }
    
    // Check if accessibility service is enabled
    fun isAccessibilityServiceEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return enabledServices?.contains("${context.packageName}/${NowPlayingAccessibilityService::class.java.name}") == true
    }
    
    // Setup capture callbacks
    DisposableEffect(Unit) {
        // Progress callback for live updates
        NowPlayingAccessibilityService.progressCallback = { trackCount, scrolls, emptyScrolls ->
            capturedTrackCount = trackCount
            scrollAttemptCount = scrolls
            captureProgress = if (emptyScrolls > 0) {
                "Found $trackCount tracks • Scroll $scrolls • Checking for more..."
            } else {
                "Found $trackCount tracks • Scroll $scrolls • Discovering new tracks!"
            }
        }
        
        // Completion callback
        NowPlayingAccessibilityService.captureCallback = { tracks ->
            // Save captured tracks
            val data = captureService.createJsonData(tracks)
            
            // Save to selected location or default
            val saveDir = if (selectedSaveLocation != null) {
                DocumentFile.fromTreeUri(context, selectedSaveLocation!!)
            } else {
                null
            }
            
            if (saveDir != null) {
                try {
                    // Create JSON file in selected directory
                    val jsonFile = saveDir.createFile("application/json", "nowplaying_${System.currentTimeMillis()}.json")
                    jsonFile?.let { file ->
                        context.contentResolver.openOutputStream(file.uri)?.use { outputStream ->
                            val jsonString = kotlinx.serialization.json.Json {
                                prettyPrint = true
                            }.encodeToString(NowPlayingData.serializer(), data)
                            outputStream.write(jsonString.toByteArray())
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            
            // Update UI with captured data
            nowPlayingData = data
            filteredTracks = data.tracks
            isCapturing = false
            captureProgress = ""
            capturedTrackCount = 0
            scrollAttemptCount = 0
            
            android.widget.Toast.makeText(
                context,
                "✓ Captured ${tracks.size} tracks after $scrollAttemptCount scrolls!",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
        
        onDispose {
            NowPlayingAccessibilityService.captureCallback = null
            NowPlayingAccessibilityService.progressCallback = null
        }
    }
    
    // Directory picker for save location
    val saveLocationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let {
            selectedSaveLocation = it
            // Get the display name
            context.contentResolver.takePersistableUriPermission(
                it,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            saveLocationName = it.lastPathSegment?.split(":")?.lastOrNull() ?: "Selected folder"
            
            // Check if accessibility service is enabled
            if (isAccessibilityServiceEnabled()) {
                // Start automatic capture
                isCapturing = true
                captureProgress = "Opening Now Playing app..."
                
                val success = captureService.openNowPlayingApp()
                if (success) {
                    // Start the accessibility service capture
                    val intent = Intent(context, NowPlayingAccessibilityService::class.java).apply {
                        action = NowPlayingAccessibilityService.ACTION_START_CAPTURE
                    }
                    context.startService(intent)
                    
                    android.widget.Toast.makeText(
                        context,
                        "Automatic capture started.",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } else {
                    isCapturing = false
                    android.widget.Toast.makeText(
                        context,
                        "Could not open Now Playing app",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                // Show accessibility permission dialog
                showAccessibilityDialog = true
            }
        }
    }
    
    // JSON import launcher
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            try {
                val jsonContent = context.contentResolver.openInputStream(it)?.use { stream ->
                    stream.bufferedReader().readText()
                }
                if (jsonContent != null) {
                    val data = NowPlayingParser.parseJson(jsonContent)
                    if (data != null) {
                        nowPlayingData = data
                        filteredTracks = data.tracks
                        android.widget.Toast.makeText(
                            context,
                            "✓ Loaded ${data.tracks.size} tracks",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        android.widget.Toast.makeText(
                            context,
                            "Failed to parse JSON file",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(
                    context,
                    "Error loading file: ${e.message}",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
    
    // Filter tracks based on search query
    LaunchedEffect(searchQuery, nowPlayingData, sortBy) {
        nowPlayingData?.let { data ->
            var tracks = if (searchQuery.isBlank()) {
                data.tracks
            } else {
                data.tracks.filter { track ->
                    track.title.contains(searchQuery, ignoreCase = true) ||
                    track.artist.contains(searchQuery, ignoreCase = true)
                }
            }
            
            // Sort tracks
            tracks = when (sortBy) {
                "title" -> tracks.sortedBy { it.title.lowercase() }
                "artist" -> tracks.sortedBy { it.artist.lowercase() }
                else -> tracks.sortedByDescending { it.date ?: "" } // Sort by date descending (newest first)
            }
            
            filteredTracks = tracks
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceContainer)
                    .padding(top = 84.dp, bottom = 24.dp, start = 20.dp, end = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Wayve library",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (nowPlayingData != null) {
                            "${nowPlayingData!!.tracks.size} tracks from ${nowPlayingData!!.device}"
                        } else {
                            "Import your Now Playing history"
                        },
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    // Microphone toggle for ambient detection
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                            modifier = Modifier.clickable {
                                // Check microphone permission
                                val hasMicPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    android.Manifest.permission.RECORD_AUDIO
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                
                                if (!hasMicPermission && !continuousMonitorEnabled) {
                                    // Request microphone permission
                                    microphonePermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                } else {
                                    // Toggle continuous monitoring
                                    continuousMonitorEnabled = !continuousMonitorEnabled
                                    
                                    if (continuousMonitorEnabled && hasMicPermission) {
                                        MonitorStarter.startMonitoring(context)
                                        android.widget.Toast.makeText(
                                            context,
                                            "Ambient detection enabled",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        MonitorStarter.stopMonitoring(context)
                                        android.widget.Toast.makeText(
                                            context,
                                            "Ambient detection disabled",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (continuousMonitorEnabled) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (continuousMonitorEnabled) {
                                        "Mic ON"
                                    } else {
                                        "Mic OFF"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (continuousMonitorEnabled) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                }
                
                // Action buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Overflow menu
                    Box {
                        IconButton(
                            onClick = { showOverflowMenu = true },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More options",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false },
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceBright)
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Import JSON",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    importLauncher.launch(arrayOf("application/json"))
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Shazam API Settings",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    showShazamSettingsDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Column {
                                            Text(
                                                text = "Open with",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = selectedMusicApp,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    showOpenWithDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            painter = painterResource(id = R.drawable.trash),
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Clear all entries",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    showClearConfirmDialog = true
                                },
                                enabled = nowPlayingData != null && nowPlayingData!!.tracks.isNotEmpty()
                            )
                        }
                    }
                    
                    // Capture/Import button
                    IconButton(
                        onClick = { 
                            showCaptureDialog = true
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Capture or Import",
                            tint = MaterialTheme.colorScheme.surface
                        )
                    }
                }
            }
            
            // Tab Row
            if (nowPlayingData != null) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { 
                            Text(
                                text = "Library",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { 
                            Text(
                                text = "Analytics",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                }
            }
            
            // Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                when {
                    nowPlayingData == null -> {
                        // Empty state
                        EmptyMusicLibrary(
                            onImportClick = { 
                                importLauncher.launch(arrayOf("application/json", "*/*"))
                            }
                        )
                    }
                    selectedTab == 0 -> {
                        // Library tab
                        MusicLibraryTab(
                            tracks = filteredTracks,
                            searchQuery = searchQuery,
                            onSearchChange = { searchQuery = it },
                            sortBy = sortBy,
                            onSortChange = { sortBy = it },
                            onPlayTrack = { track ->
                                // Open selected music app with search query
                                val searchQuery = "${track.title} ${track.artist}"
                                val intent = when (selectedMusicApp) {
                                    "YouTube" -> Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(searchQuery)}")
                                    }
                                    "Spotify" -> Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("spotify:search:${Uri.encode(searchQuery)}")
                                    }
                                    "YT Music" -> Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("https://music.youtube.com/search?q=${Uri.encode(searchQuery)}")
                                    }
                                    "YT Revanced" -> Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("https://music.youtube.com/search?q=${Uri.encode(searchQuery)}")
                                        setPackage("app.revanced.android.apps.youtube.music")
                                    }
                                    else -> Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(searchQuery)}")
                                    }
                                }
                                try {
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "Unable to open $selectedMusicApp. Please make sure it's installed.",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                    }
                    selectedTab == 1 -> {
                        // Analytics tab
                        AnalyticsTab(nowPlayingData!!)
                    }
                }
            }
        }
        
        // Capture Dialog
        if (showCaptureDialog) {
            CaptureDialog(
                captureService = captureService,
                onDismiss = { showCaptureDialog = false },
                onImportClick = {
                    showCaptureDialog = false
                    importLauncher.launch(arrayOf("application/json", "*/*"))
                },
                onSelectSaveLocation = {
                    showCaptureDialog = false
                    saveLocationLauncher.launch(null)
                }
            )
        }
        
        // Accessibility Dialog
        if (showAccessibilityDialog) {
            AccessibilityPermissionDialog(
                onDismiss = { showAccessibilityDialog = false },
                onOpenSettings = {
                    showAccessibilityDialog = false
                    // Open accessibility settings
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    context.startActivity(intent)
                    
                    android.widget.Toast.makeText(
                        context,
                        "Enable 'wayve' in Accessibility settings, then try capture again",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            )
        }
        
        // Clear confirmation dialog
        if (showClearConfirmDialog) {
            ClearAllConfirmDialog(
                trackCount = nowPlayingData?.tracks?.size ?: 0,
                onDismiss = { showClearConfirmDialog = false },
                onConfirm = {
                    nowPlayingData = null
                    filteredTracks = emptyList()
                    showClearConfirmDialog = false
                    
                    // Clear saved data
                    sharedPrefs.edit().remove("nowplaying_data").apply()
                    
                    android.widget.Toast.makeText(
                        context,
                        "All entries cleared",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }
        
        // Open with dialog
        if (showOpenWithDialog) {
            OpenWithDialog(
                currentApp = selectedMusicApp,
                onDismiss = { showOpenWithDialog = false },
                onAppSelected = { app ->
                    selectedMusicApp = app
                    showOpenWithDialog = false
                }
            )
        }
        
        // Shazam API Settings dialog
        if (showShazamSettingsDialog) {
            com.romnix.app.ui.dialogs.ShazamSettingsDialog(
                sharedPrefs = sharedPrefs,
                onDismiss = { showShazamSettingsDialog = false }
            )
        }
        
        // Notification listener permission dialog
        if (showNotificationListenerDialog) {
            NotificationListenerPermissionDialog(
                onDismiss = { showNotificationListenerDialog = false },
                onOpenSettings = {
                    showNotificationListenerDialog = false
                    // Open notification listener settings
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    context.startActivity(intent)
                    
                    android.widget.Toast.makeText(
                        context,
                        "Enable 'wayve' in Notification Access settings",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            )
        }
        
        // Capturing progress overlay
        if (isCapturing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.95f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(32.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(64.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Text(
                        text = "Capturing music history...",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    if (capturedTrackCount > 0) {
                        Card(
                            modifier = Modifier.fillMaxWidth(0.8f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "🎵 $capturedTrackCount tracks",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = captureProgress,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Opening Now Playing...\nStarting to scan your history",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "This may take a few minutes\nDepending on your history size",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun CaptureDialog(
    captureService: NowPlayingCaptureService,
    onDismiss: () -> Unit,
    onImportClick: () -> Unit,
    onSelectSaveLocation: () -> Unit
) {
    val context = LocalContext.current
    
    // Check if accessibility is enabled
    fun isAccessibilityEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return enabledServices?.contains("${context.packageName}/${NowPlayingAccessibilityService::class.java.name}") == true
    }
    
    val accessibilityEnabled = remember { mutableStateOf(isAccessibilityEnabled()) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceBright
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Add music history",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Follow these steps to capture your Now Playing history",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Step 1: Enable Accessibility
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !accessibilityEnabled.value) {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (accessibilityEnabled.value) 
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    if (accessibilityEnabled.value)
                                        MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (accessibilityEnabled.value) "✓" else "1",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (accessibilityEnabled.value)
                                    MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Accessibility permission",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (accessibilityEnabled.value) "✓ Enabled" else "Tap to enable in Settings",
                                fontSize = 13.sp,
                                color = if (accessibilityEnabled.value)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Step 2: Choose save location - opens folder picker directly
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSaveLocation() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "2",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Choose save location",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Where to save JSON file",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Step 3: Capture Now Playing - opens folder picker and starts capture
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSaveLocation() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "3",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Capture Now Playing",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Tap to start capture",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AccessibilityPermissionDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceBright
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Enable accessibility",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Explanation
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "✨", fontSize = 24.sp)
                        Column {
                            Text(
                                text = "Automatic capture",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "wayve can automatically read your Now Playing history, scroll through pages, and extract all track data.",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Instructions
                Text(
                    text = "To enable automatic capture:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Column(
                    modifier = Modifier.padding(start = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("1.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Tap 'Open Settings' below",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("2.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Find 'wayve' in the list",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Toggle the switch to ON",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("4.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Return and try capture again",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Privacy note
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🔒", fontSize = 16.sp)
                        Text(
                            text = "Privacy: This only reads from the Now Playing app. Your data stays on your device.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenSettings,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("OPEN SETTINGS")
                    }
                }
            }
        }
    }
}

@Composable
private fun ClearAllConfirmDialog(
    trackCount: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceBright
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Clear all entries",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Remove all $trackCount tracks from your library?",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        Text(
                            text = "CLEAR ALL",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        Text(
                            text = "CANCEL",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationListenerPermissionDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceBright
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Enable auto-detection",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Explanation
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "🎵", fontSize = 24.sp)
                        Column {
                            Text(
                                text = "Automatic song detection",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "wayve will automatically detect songs from Now Playing and add them to your library in real-time.",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Instructions
                Text(
                    text = "To enable automatic detection:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Column(
                    modifier = Modifier.padding(start = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("1.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Tap 'Open Settings' below",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("2.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Find 'wayve' in the list",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Toggle the switch to ON",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("4.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Return and enable auto-detection",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Privacy note
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🔒", fontSize = 16.sp)
                        Text(
                            text = "Privacy: This only reads Now Playing notifications. Your data stays on your device.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenSettings,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("OPEN SETTINGS")
                    }
                }
            }
        }
    }
}

@Composable
private fun OpenWithDialog(
    currentApp: String,
    onDismiss: () -> Unit,
    onAppSelected: (String) -> Unit
) {
    val apps = listOf("YouTube", "Spotify", "YT Music", "YT Revanced")
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceBright
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Open with",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Choose which app to use when playing songs",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // App options
                apps.forEach { app ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAppSelected(app) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (app == currentApp) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerLow
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = if (app == currentApp) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                                Text(
                                    text = app,
                                    fontSize = 16.sp,
                                    color = if (app == currentApp) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                            if (app == currentApp) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                    if (app != apps.last()) {
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Cancel button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = "CANCEL",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyMusicLibrary(onImportClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.emptystate),
            contentDescription = "Empty state",
            modifier = Modifier.size(120.dp),
            colorFilter = ColorFilter.tint(surfaceVariantDarker())
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "No music history",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(2.dp))
        
        Text(
            text = "Tap + button to start",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}

@Composable
private fun MusicLibraryTab(
    tracks: List<NowPlayingTrack>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    sortBy: String,
    onSortChange: (String) -> Unit,
    onPlayTrack: (NowPlayingTrack) -> Unit
) {
    var showSortMenu by remember { mutableStateOf(false) }
    
    Column(modifier = Modifier.fillMaxSize()) {
        // Search and sort controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search tracks or artists...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceBright,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceBright
                )
            )
            
            // Sort button
            Box {
                IconButton(
                    onClick = { showSortMenu = true },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Sort",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false },
                    modifier = Modifier
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.surfaceBright)
                ) {
                    DropdownMenuItem(
                        text = { Text("Sort by Time") },
                        onClick = {
                            onSortChange("time")
                            showSortMenu = false
                        },
                        leadingIcon = {
                            if (sortBy == "time") {
                                Icon(Icons.Default.Check, contentDescription = null)
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sort by Title") },
                        onClick = {
                            onSortChange("title")
                            showSortMenu = false
                        },
                        leadingIcon = {
                            if (sortBy == "title") {
                                Icon(Icons.Default.Check, contentDescription = null)
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sort by Artist") },
                        onClick = {
                            onSortChange("artist")
                            showSortMenu = false
                        },
                        leadingIcon = {
                            if (sortBy == "artist") {
                                Icon(Icons.Default.Check, contentDescription = null)
                            }
                        }
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Track count
        Text(
            text = "${tracks.size} tracks",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        // Track list
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (tracks.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No tracks match your search",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                // Group by date if sorting by time
                if (sortBy == "time") {
                    val groupedTracks = tracks.groupBy { it.date }
                    
                    groupedTracks.forEach { (date, tracksInGroup) ->
                        // Date header
                        item(key = "header_$date") {
                            Text(
                                text = formatDateHeader(date),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                            )
                        }
                        
                        // Tracks in this date group
                        itemsIndexed(tracksInGroup, key = { idx, track -> "${date}_${idx}_${track.title}" }) { index, track ->
                            val isFirst = index == 0
                            val isLast = index == tracksInGroup.lastIndex
                            val isSingle = tracksInGroup.size == 1
                            
                            val shape = when {
                                isSingle -> RoundedCornerShape(28.dp)
                                isFirst -> RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                                isLast -> RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                                else -> RoundedCornerShape(0.dp)
                            }
                            
                            TrackCard(
                                track = track,
                                shape = shape,
                                onClick = { onPlayTrack(track) }
                            )
                        }
                        
                        // Spacer between date groups
                        item(key = "spacer_$date") {
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                } else if (sortBy == "artist") {
                    // Group by artist if sorting by artist
                    val groupedTracks = tracks.groupBy { it.artist }
                    
                    groupedTracks.forEach { (artist, tracksInGroup) ->
                        // Artist header
                        item(key = "header_$artist") {
                            Text(
                                text = artist,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                            )
                        }
                        
                        // Tracks in this artist group
                        itemsIndexed(tracksInGroup, key = { idx, track -> "${artist}_${idx}_${track.title}" }) { index, track ->
                            val isFirst = index == 0
                            val isLast = index == tracksInGroup.lastIndex
                            val isSingle = tracksInGroup.size == 1
                            
                            val shape = when {
                                isSingle -> RoundedCornerShape(28.dp)
                                isFirst -> RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                                isLast -> RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                                else -> RoundedCornerShape(0.dp)
                            }
                            
                            TrackCard(
                                track = track,
                                shape = shape,
                                onClick = { onPlayTrack(track) }
                            )
                        }
                        
                        // Spacer between artist groups
                        item(key = "spacer_$artist") {
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                } else {
                    // No grouping for title sort mode
                    itemsIndexed(tracks) { index, track ->
                        val isFirst = index == 0
                        val isLast = index == tracks.lastIndex
                        val isSingle = tracks.size == 1
                        
                        val shape = when {
                            isSingle -> RoundedCornerShape(28.dp)
                            isFirst -> RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                            isLast -> RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                            else -> RoundedCornerShape(0.dp)
                        }
                        
                        TrackCard(
                            track = track,
                            shape = shape,
                            onClick = { onPlayTrack(track) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackCard(
    track: NowPlayingTrack,
    shape: RoundedCornerShape,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceBright
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Music note icon
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🎵",
                        fontSize = 24.sp
                    )
                }
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = track.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (track.favorited) {
                            Text(text = "❤️", fontSize = 14.sp)
                        }
                    }
                    
                    Text(
                        text = buildString {
                            append(track.artist)
                            if (track.time != null) {
                                append(" • ${track.time}")
                            }
                        },
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            
            // Play button
            IconButton(
                onClick = onClick,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

@Composable
private fun AnalyticsTab(data: NowPlayingData) {
    val stats = data.statistics ?: NowPlayingParser.calculateStats(data.tracks)
    
    // Calculate duplicates (songs that appear more than once)
    val duplicatesCount = data.tracks
        .groupBy { "${it.title}|${it.artist}" }
        .filter { it.value.size > 1 }
        .values
        .sumOf { it.size - 1 } // Count only the duplicate occurrences
    
    // Calculate top songs (most played) - only duplicates
    val topSongs = data.tracks
        .groupBy { "${it.title}|${it.artist}" }
        .mapValues { it.value.size }
        .filter { it.value > 1 } // Only show songs played more than once
        .toList()
        .sortedByDescending { it.second }
        .take(10)
    
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Stats cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Duplicates",
                    value = duplicatesCount.toString(),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Unique Artists",
                    value = stats.unique_artists.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Unique Songs",
                    value = stats.unique_songs.toString(),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Favorited",
                    value = stats.favorited_count.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        // Top Songs by Artists (only duplicates)
        if (topSongs.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "Top Songs by Artists",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "Songs you've played multiple times",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        topSongs.forEach { (songKey, count) ->
                            val (title, artist) = songKey.split("|")
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            ) {
                                Text(
                                    text = title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = artist,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer)
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "${count}x played",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Most Played Songs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceBright
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "Most Played Songs",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Table header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SONG",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "PLAYS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(60.dp)
                        )
                    }
                    
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        thickness = 1.dp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    if (topSongs.isEmpty()) {
                        Text(
                            text = "No duplicate songs found",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        topSongs.forEachIndexed { index, (songKey, count) ->
                            val (title, artist) = songKey.split("|")
                            
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Rank badge
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (index) {
                                                    0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                                    1 -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                                    2 -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (index) {
                                                0 -> MaterialTheme.colorScheme.primary
                                                1 -> MaterialTheme.colorScheme.secondary
                                                2 -> MaterialTheme.colorScheme.tertiary
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    // Song info
                                    Column(
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = title,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = artist,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    
                                    // Play count badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .width(60.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${count}x",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                
                                if (index < topSongs.size - 1) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                        thickness = 0.5.dp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }
}

private fun formatDate(dateString: String): String {
    return try {
        val date = java.time.LocalDate.parse(dateString)
        val today = java.time.LocalDate.now()
        val yesterday = today.minusDays(1)
        
        when (date) {
            today -> "Today"
            yesterday -> "Yesterday"
            else -> {
                val formatter = java.time.format.DateTimeFormatter.ofPattern("MMM d, yyyy")
                date.format(formatter)
            }
        }
    } catch (e: Exception) {
        dateString
    }
}

private fun formatDateHeader(dateString: String?): String {
    if (dateString == null) return "Unknown Date"
    
    return try {
        val date = java.time.LocalDate.parse(dateString)
        val today = java.time.LocalDate.now()
        val yesterday = today.minusDays(1)
        
        when (date) {
            today -> "Today"
            yesterday -> "Yesterday"
            else -> {
                // Format like "Sunday, October 26"
                val formatter = java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")
                date.format(formatter)
            }
        }
    } catch (e: Exception) {
        dateString
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = title,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.9f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

