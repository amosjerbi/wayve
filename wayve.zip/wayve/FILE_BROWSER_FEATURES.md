# File Browser Features

## Overview
Added a comprehensive file browsing system for connected devices with full file management capabilities over SSH/SFTP.

## New Components

### 1. SshFileManager.kt (`app/src/main/java/com/romnix/app/network/SshFileManager.kt`)
Backend service that handles all SSH/SFTP operations:

**Core Operations:**
- **listFiles()** - Browse remote directories with full file metadata
- **renameFile()** - Rename files and folders
- **copyFile()** - Copy files and folders (recursive)
- **deleteFile()** - Delete files and folders (recursive for directories)
- **createDirectory()** - Create new folders
- **getFileInfo()** - Get detailed file information

**Features:**
- Automatic SSH authentication with multiple password attempts
- Recursive directory operations
- Error handling with Result types
- BouncyCastle security provider integration

### 2. FileBrowserScreen.kt (`app/src/main/java/com/romnix/app/ui/screens/FileBrowserScreen.kt`)
Modern Material 3 UI for file browsing:

**UI Components:**
- **Navigation** - Back button, breadcrumb path display
- **File List** - LazyColumn with folders first, then files
- **File Items** - Icon, name, size, tap to open, long-press for options
- **Parent Directory** - ".." entry to navigate up
- **Empty States** - Helpful messages for empty directories or errors
- **Loading States** - Progress indicators during operations

**File Operations Menu:**
When long-pressing a file/folder:
- **Rename** - Edit name with text field dialog
- **Copy** - Copy to new location with path input
- **Delete** - Confirmation dialog with warning
- **Cancel** - Close menu

**Additional Features:**
- **Create Folder** - FAB button in header to create new directories
- **Path Display** - Shows current directory path
- **File Size Formatting** - Human-readable sizes (B, KB, MB, GB)
- **Error Handling** - Toast messages and error states

### 3. MainViewModel Updates (`app/src/main/java/com/romnix/app/MainActivity.kt`)
Added file browser methods:

- `listRemoteFiles()` - List directory contents
- `renameRemoteFile()` - Rename operation
- `deleteRemoteFile()` - Delete operation
- `copyRemoteFile()` - Copy operation
- `createRemoteDirectory()` - Create folder operation

All methods:
- Use current device connection settings
- Execute on IO dispatcher
- Return results via callbacks
- Handle authentication automatically

### 4. DevicesScreen Integration (`app/src/main/java/com/romnix/app/ui/screens/DevicesScreen.kt`)
Enhanced device cards with file browser access:

**New Features:**
- **Browse Files Button** - Folder icon button on each device card
- **Connection Check** - Requires device to be connected first
- **Device Name Tracking** - Passes device name to file browser
- **Seamless Navigation** - Toggle between device list and file browser

## How to Use

### For Users:
1. **Connect to Device** - Tap "CONNECT" on a device card
2. **Browse Files** - Tap the folder icon button (left of Edit button)
3. **Navigate** - Tap folders to open, ".." to go up
4. **File Operations** - Long-press any file/folder for options
5. **Create Folders** - Tap the "+" folder icon in the header
6. **Back to Devices** - Tap back arrow to return

### File Operations:
- **Rename**: Long-press → Rename → Enter new name → RENAME
- **Copy**: Long-press → Copy → Enter destination path → COPY
- **Delete**: Long-press → Delete → Confirm → DELETE
- **Create Folder**: Tap + icon → Enter name → CREATE

## Technical Details

### SSH Connection
- Uses SSHJ library for SSH/SFTP operations
- Automatic password fallback (device password, then "root", "rocknix", "muos")
- 15-second connection timeout
- 20-second operation timeout
- BouncyCastle provider for legacy algorithm support

### UI/UX Features
- Material 3 design system
- Theme-aware colors (light/dark mode)
- Smooth animations and transitions
- Proper error messages
- Loading indicators
- Touch feedback
- Long-press gesture support

### File Metadata
Each file/folder includes:
- Name
- Full path
- Type (file/directory)
- Size (bytes)
- Permissions
- Last modified time

### Error Handling
- Connection failures
- Authentication errors
- Permission denied
- Path not found
- Operation failures
- User-friendly error messages

## Supported Devices
Works with all SSH-enabled devices including:
- Lakka
- Rocknix
- muOS
- ArkOS
- Anbernic
- Custom devices

## Build Status
✅ Successfully compiled and tested
✅ No linter errors
✅ All features integrated

## Future Enhancements
Possible additions:
- File upload from Android device
- File download to Android device
- File preview (text/images)
- Bulk operations (multi-select)
- Search within directories
- Sort options (name, size, date)
- Favorites/bookmarks
- Path history

